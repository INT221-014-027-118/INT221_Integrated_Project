package com.example.demominio.controller;

import com.example.demominio.models.Colors;
import com.example.demominio.repository.ColorsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/colors")
public class ColorsController {
    @Autowired
    private ColorsRepository colorsRepository;

    @GetMapping("/getall")
    public List<Colors> getAllProduct(){
        return colorsRepository.findAll();
    }
}
