package com.example.demominio.controller;

import com.example.demominio.models.ProductWarranty;
import com.example.demominio.repository.ProductWarrantyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/warranty")
public class ProductWarrantyController {
    @Autowired
    private ProductWarrantyRepository productWarrantyRepository;

    @GetMapping("/getall")
    public List<ProductWarranty> getAllWarranty(){
        return productWarrantyRepository.findAll();
    }
}
