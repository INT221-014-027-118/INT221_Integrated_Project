package com.example.demominio.controller;

import com.example.demominio.models.Products;
import com.example.demominio.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductsController {

    @Autowired
    private ProductRepository productRepository;

    @GetMapping("/getall")
    public List<Products> getAllProduct() {
        return productRepository.findAll();
    }

//    @PostMapping("/addcolor")
//    public AddColorProduct addColorProduct(@RequestBody() AddColorProduct addColorProduct)throws Exception{
//        List<Colors> colors = colorsRepository.findAll();
//        for (int i = 0; i < addColorProduct.getColorId().size(); i++) {
//            for (int j = 0; j < colors.size(); j++) {
//                if (addColorProduct.getColorId().get(i) == colors.get(j).getColorId()){
//                    System.out.println(colors.get(j).toString());
//                }
//            }
//        }
//        return addColorProduct;
//    }
}
