package com.refundgarantee.int221Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Int221ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
