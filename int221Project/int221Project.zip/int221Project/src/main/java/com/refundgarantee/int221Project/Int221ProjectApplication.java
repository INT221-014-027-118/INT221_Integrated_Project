package com.refundgarantee.int221Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Int221ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Int221ProjectApplication.class, args);
	}

}
