package Refun.Int221;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;


@SpringBootTest
class Int221ApplicationTests {

	@Test
	void contextLoads() {
	}

}
